package com.noir.hitech.player.util

import android.net.Uri
import com.noir.hitech.player.model.StreamProtocol

data class ValidationResult(
    val isValidDirectStream: Boolean,
    val protocol: StreamProtocol,
    val warningMessage: String? = null,
    val recommendation: String? = null
)

object StreamValidator {
    fun validateMediaUrl(rawUrl: String): ValidationResult {
        val trimmed = rawUrl.trim()
        if (trimmed.isEmpty()) {
            return ValidationResult(isValidDirectStream = false, protocol = StreamProtocol.UNKNOWN, warningMessage = "Media URL cannot be empty.")
        }
        val lower = trimmed.lowercase()
        if (lower.contains("t.me/") || lower.contains("telegram.me/")) {
            return ValidationResult(
                isValidDirectStream = false,
                protocol = StreamProtocol.UNKNOWN,
                warningMessage = "Telegram link detected. 't.me/...' are web preview pages, not direct video streams.",
                recommendation = "Provide a direct CDN stream URL (.mp4, .m3u8, .mpd) or use the authorized Telegram Bot / MTProto API."
            )
        }
        if (lower.contains("drive.google.com/file/d/")) {
            return ValidationResult(
                isValidDirectStream = false,
                protocol = StreamProtocol.UNKNOWN,
                warningMessage = "Google Drive share link detected. This serves an HTML viewer, not a direct media stream.",
                recommendation = "Export file as direct media stream or supply a direct cloud storage CDN link."
            )
        }
        val uri = try { Uri.parse(trimmed) } catch (e: Exception) { return ValidationResult(isValidDirectStream = false, protocol = StreamProtocol.UNKNOWN, warningMessage = "Invalid URI syntax") }
        val path = uri.path?.lowercase() ?: ""
        val protocol = when {
            path.endsWith(".m3u8") -> StreamProtocol.HLS_M3U8
            path.endsWith(".mpd") -> StreamProtocol.DASH_MPD
            path.endsWith(".mp4") || path.endsWith(".m4v") -> StreamProtocol.DIRECT_MP4
            path.endsWith(".webm") -> StreamProtocol.DIRECT_WEBM
            else -> StreamProtocol.UNKNOWN
        }
        return ValidationResult(isValidDirectStream = true, protocol = protocol)
    }
}