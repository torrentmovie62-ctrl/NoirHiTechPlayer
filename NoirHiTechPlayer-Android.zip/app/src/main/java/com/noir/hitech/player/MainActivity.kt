package com.noir.hitech.player

import android.content.pm.ActivityInfo
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.noir.hitech.player.model.ActiveMedia
import com.noir.hitech.player.model.StreamProtocol
import com.noir.hitech.player.player.NoirPlayerManager
import com.noir.hitech.player.ui.PlayerScreen
import com.noir.hitech.player.ui.components.UrlInputDialog
import com.noir.hitech.player.ui.theme.NoirBlack
import com.noir.hitech.player.ui.theme.NoirHiTechPlayerTheme

class MainActivity : ComponentActivity() {

    private lateinit var playerManager: NoirPlayerManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        playerManager = NoirPlayerManager(this)

        intent?.data?.let { uri ->
            playerManager.playMedia(
                ActiveMedia(
                    uri = uri,
                    title = uri.lastPathSegment ?: "Direct Stream",
                    protocol = StreamProtocol.UNKNOWN
                )
            )
        }

        setContent {
            NoirHiTechPlayerTheme {
                var showUrlDialog by remember { mutableStateOf(false) }
                var isLandscape by remember { mutableStateOf(false) }

                val videoPickerLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.GetContent()
                ) { uri: Uri? ->
                    uri?.let {
                        val fileName = it.lastPathSegment ?: "Local Video"
                        playerManager.playMedia(
                            ActiveMedia(
                                uri = it,
                                title = fileName,
                                protocol = StreamProtocol.LOCAL_STORAGE
                            )
                        )
                    }
                }

                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = NoirBlack
                ) {
                    PlayerScreen(
                        playerManager = playerManager,
                        onOpenLocalFile = { videoPickerLauncher.launch("video/*") },
                        onPasteUrl = { showUrlDialog = true },
                        onToggleFullscreen = {
                            isLandscape = !isLandscape
                            requestedOrientation = if (isLandscape) {
                                ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
                            } else {
                                ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                            }
                        }
                    )

                    if (showUrlDialog) {
                        UrlInputDialog(
                            onConfirm = { url, subtitleUrl ->
                                showUrlDialog = false
                                playerManager.playMedia(
                                    ActiveMedia(
                                        uri = Uri.parse(url),
                                        title = Uri.parse(url).lastPathSegment ?: "Network Stream",
                                        protocol = StreamProtocol.UNKNOWN,
                                        externalSubtitleUri = subtitleUrl?.let { Uri.parse(it) }
                                    )
                                )
                            },
                            onDismiss = { showUrlDialog = false }
                        )
                    }
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        playerManager.release()
    }
}