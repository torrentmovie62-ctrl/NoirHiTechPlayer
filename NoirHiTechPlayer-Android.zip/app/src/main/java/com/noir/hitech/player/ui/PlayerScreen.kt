package com.noir.hitech.player.ui

import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.annotation.OptIn
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.util.UnstableApi
import androidx.media3.ui.PlayerView
import com.noir.hitech.player.player.NoirPlayerManager
import com.noir.hitech.player.ui.components.*
import com.noir.hitech.player.ui.theme.*

@OptIn(UnstableApi::class)
@Composable
fun PlayerScreen(
    playerManager: NoirPlayerManager,
    onOpenLocalFile: () -> Unit,
    onPasteUrl: () -> Unit,
    onToggleFullscreen: () -> Unit
) {
    val state by playerManager.playbackState.collectAsState()
    var areControlsVisible by remember { mutableStateOf(true) }
    var showSpeedDialog by remember { mutableStateOf(false) }
    var showAudioSheet by remember { mutableStateOf(false) }
    var showSubtitleSheet by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(NoirBlack)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) {
                areControlsVisible = !areControlsVisible
            }
    ) {
        AndroidView(
            factory = { ctx ->
                PlayerView(ctx).apply {
                    player = playerManager.exoPlayer
                    useController = false
                    layoutParams = FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                }
            },
            modifier = Modifier.fillMaxSize()
        )

        if (state.isBuffering) {
            CircularProgressIndicator(
                color = CyanNeon,
                modifier = Modifier.size(54.dp).align(Alignment.Center)
            )
        }

        if (state.errorMessage != null) {
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = RoseAlert.copy(alpha = 0.9f),
                modifier = Modifier.align(Alignment.Center).padding(24.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("PLAYBACK ERROR", color = Color.White, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(state.errorMessage ?: "", color = Color.White, fontSize = 12.sp)
                }
            }
        }

        HiTechControlsOverlay(
            state = state,
            isVisible = areControlsVisible,
            onTogglePlay = { playerManager.togglePlayPause() },
            onSeek = { playerManager.seekTo(it) },
            onSeekForward = { playerManager.seekForward() },
            onSeekBackward = { playerManager.seekBackward() },
            onOpenSpeedMenu = { showSpeedDialog = true },
            onOpenAudioTracks = { showAudioSheet = true },
            onOpenSubtitles = { showSubtitleSheet = true },
            onToggleFullscreen = onToggleFullscreen
        )
    }
}