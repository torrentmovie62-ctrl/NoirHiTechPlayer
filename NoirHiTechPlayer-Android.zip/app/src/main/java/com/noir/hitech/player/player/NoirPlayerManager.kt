package com.noir.hitech.player.player

import android.content.Context
import android.net.Uri
import androidx.annotation.OptIn
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.common.TrackGroup
import androidx.media3.common.Tracks
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import com.noir.hitech.player.model.ActiveMedia
import com.noir.hitech.player.model.PlaybackState
import com.noir.hitech.player.model.TrackInfo
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

@OptIn(UnstableApi::class)
class NoirPlayerManager(private val context: Context) {

    private val trackSelector = DefaultTrackSelector(context)
    val exoPlayer: ExoPlayer

    private val _playbackState = MutableStateFlow(PlaybackState())
    val playbackState: StateFlow<PlaybackState> = _playbackState.asStateFlow()

    private var progressJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.Main + Job())

    init {
        // Configure HTTP Data Source with redirect and user agent handling
        val httpDataSourceFactory = DefaultHttpDataSource.Factory()
            .setUserAgent("NOIR-HITECH-Player/1.0.0 (Android ExoPlayer)")
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15_000)
            .setReadTimeoutMs(20_000)

        val mediaSourceFactory = DefaultMediaSourceFactory(context)
            .setDataSourceFactory(httpDataSourceFactory)

        exoPlayer = ExoPlayer.Builder(context)
            .setTrackSelector(trackSelector)
            .setMediaSourceFactory(mediaSourceFactory)
            .setSeekBackIncrementMs(10_000)
            .setSeekForwardIncrementMs(10_000)
            .build()

        setupPlayerListeners()
    }

    private fun setupPlayerListeners() {
        exoPlayer.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                val isBuffering = state == Player.STATE_BUFFERING
                _playbackState.value = _playbackState.value.copy(
                    isBuffering = isBuffering,
                    durationMs = exoPlayer.duration.coerceAtLeast(0L),
                    errorMessage = if (state != Player.STATE_IDLE) null else _playbackState.value.errorMessage
                )
                if (state == Player.STATE_READY) {
                    startProgressTracker()
                }
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) {
                _playbackState.value = _playbackState.value.copy(isPlaying = isPlaying)
                if (isPlaying) {
                    startProgressTracker()
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                val friendlyMessage = when (error.errorCode) {
                    PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED,
                    PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT ->
                        "Network error: Unable to connect to stream server. Check your connection."
                    PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS ->
                        "HTTP error: Server returned an unauthorized or not-found status."
                    PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED,
                    PlaybackException.ERROR_CODE_PARSING_MANIFEST_UNSUPPORTED ->
                        "Format error: Stream container or manifest (.m3u8/.mpd) could not be parsed."
                    PlaybackException.ERROR_CODE_DECODER_INIT_FAILED ->
                        "Codec error: Hardware video decoder could not be initialized for this profile."
                    else -> "Playback error: ${error.localizedMessage ?: "Unknown ExoPlayer error (${error.errorCode})"}"
                }
                _playbackState.value = _playbackState.value.copy(
                    errorMessage = friendlyMessage,
                    isBuffering = false
                )
            }

            override fun onTracksChanged(tracks: Tracks) {
                extractTracks(tracks)
            }
        })
    }

    private fun extractTracks(tracks: Tracks) {
        val audioList = mutableListOf<TrackInfo>()
        val subtitleList = mutableListOf<TrackInfo>()

        for (group in tracks.groups) {
            val trackType = group.type
            val trackGroup: TrackGroup = group.mediaTrackGroup

            for (i in 0 until trackGroup.length) {
                val format = trackGroup.getFormat(i)
                val isSelected = group.isTrackSelected(i)
                val id = format.id ?: "$trackType-$i"
                val name = format.label ?: format.language ?: "Track ${i + 1}"

                val info = TrackInfo(
                    id = id,
                    name = name,
                    language = format.language,
                    isSelected = isSelected,
                    mimeType = format.sampleMimeType
                )

                if (trackType == C.TRACK_TYPE_AUDIO) {
                    audioList.add(info)
                } else if (trackType == C.TRACK_TYPE_TEXT) {
                    subtitleList.add(info)
                }
            }
        }

        val videoFormat = exoPlayer.videoFormat
        val res = if (videoFormat != null && videoFormat.width > 0 && videoFormat.height > 0) {
            "${videoFormat.width}x${videoFormat.height}"
        } else {
            "--"
        }

        _playbackState.value = _playbackState.value.copy(
            audioTracks = audioList,
            subtitleTracks = subtitleList,
            videoResolution = res
        )
    }

    fun playMedia(media: ActiveMedia) {
        val mediaItemBuilder = MediaItem.Builder().setUri(media.uri)

        if (media.externalSubtitleUri != null) {
            val mimeType = media.externalSubtitleMime ?: MimeTypes.TEXT_VTT
            val subtitleConfig = MediaItem.SubtitleConfiguration.Builder(media.externalSubtitleUri)
                .setMimeType(mimeType)
                .setLanguage("en")
                .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
                .build()
            mediaItemBuilder.setSubtitleConfigurations(listOf(subtitleConfig))
        }

        val mediaItem = mediaItemBuilder.build()
        exoPlayer.setMediaItem(mediaItem)
        exoPlayer.prepare()
        exoPlayer.playWhenReady = true

        _playbackState.value = _playbackState.value.copy(
            mediaTitle = media.title,
            errorMessage = null,
            currentPositionMs = 0L
        )
    }

    fun togglePlayPause() {
        if (exoPlayer.isPlaying) {
            exoPlayer.pause()
        } else {
            exoPlayer.play()
        }
    }

    fun seekTo(positionMs: Long) {
        exoPlayer.seekTo(positionMs.coerceIn(0L, exoPlayer.duration.coerceAtLeast(0L)))
    }

    fun seekForward(deltaMs: Long = 10_000L) {
        seekTo(exoPlayer.currentPosition + deltaMs)
    }

    fun seekBackward(deltaMs: Long = 10_000L) {
        seekTo(exoPlayer.currentPosition - deltaMs)
    }

    fun setPlaybackSpeed(speed: Float) {
        exoPlayer.playbackParameters = PlaybackParameters(speed)
        _playbackState.value = _playbackState.value.copy(playbackSpeed = speed)
    }

    fun selectSubtitleTrack(trackIndex: Int?) {
        val parameters = trackSelector.buildUponParameters()
        if (trackIndex == null) {
            parameters.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
        } else {
            parameters.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
        }
        trackSelector.setParameters(parameters)
    }

    private fun startProgressTracker() {
        progressJob?.cancel()
        progressJob = scope.launch {
            while (isActive) {
                if (exoPlayer.playbackState == Player.STATE_READY || exoPlayer.isPlaying) {
                    _playbackState.value = _playbackState.value.copy(
                        currentPositionMs = exoPlayer.currentPosition.coerceAtLeast(0L),
                        durationMs = exoPlayer.duration.coerceAtLeast(0L),
                        bufferedPositionMs = exoPlayer.bufferedPosition.coerceAtLeast(0L)
                    )
                }
                delay(250)
            }
        }
    }

    fun release() {
        progressJob?.cancel()
        exoPlayer.release()
    }
}