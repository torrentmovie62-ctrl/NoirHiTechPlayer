# NOIR HITECH Player — Android Project

Built with Kotlin, Jetpack Compose, and AndroidX Media3 ExoPlayer 1.5.1.
To build in Android Studio:
1. Open this folder in Android Studio Ladybug/Hedgehog.
2. Run `./gradlew assembleDebug` or click Run.